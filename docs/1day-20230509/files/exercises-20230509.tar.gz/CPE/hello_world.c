// Simple C program to display "Hello World"

// Header file for input output functions
#include <stdio.h>

// main function -
// where the execution of program begins
int main()
{

    // prints hello world
    printf( "Hello World\n" );

    return 0;
}
